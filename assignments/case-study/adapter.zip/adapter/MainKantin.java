package com.kuliah.pattern.adapter;

public class MainKantin {
    public static void main(String[] args) {
        System.out.println("=== SIMULASI KASIR KANTIN KAMPUS ===\n");

        // Scenario 1: Mahasiswa bayar Pakai Tunai
        Pembayaran kasirTunai = new PembayaranTunai();
        kasirTunai.prosesBayar(15000);

        System.out.println("\n------------------------------------\n");

        // Scenario 2: Mahasiswa bayar Pakai GoPay (via Adapter)
        VendorGoPayService sdkGoPay = new VendorGoPayService("MCH-KAMPUS-UNIV");

        // Bungkus SDK GoPay dengan Adapter
        Pembayaran kasirGoPay = new GoPayAdapter(sdkGoPay);

        // Kasir cukup memanggil method standar prosesBayar() tanpa tahu kerumitan SDK vendor!
        kasirGoPay.prosesBayar(25000);
    }
}